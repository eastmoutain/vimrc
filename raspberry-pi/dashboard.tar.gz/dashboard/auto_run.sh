#!/bin/bash

/usr/local/bin/clash -ext-ui /home/pi/software/clash-dashboard -f /home/pi/.config/clash/crolax.yaml &
