#!/bin/bash
./clash -f crolax.yaml -d . -ext-ui dashboard
